=====
Usage
=====

To use Python polarization in a project::

    import py_pol
