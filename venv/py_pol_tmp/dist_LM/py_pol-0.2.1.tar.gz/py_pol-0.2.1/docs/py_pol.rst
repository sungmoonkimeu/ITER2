py\_pol package
===============

Submodules
----------

py\_pol.drawings module
-----------------------

.. automodule:: py_pol.drawings
    :members:
    :undoc-members:
    :show-inheritance:

py\_pol.jones\_matrix module
----------------------------

.. automodule:: py_pol.jones_matrix
    :members:
    :undoc-members:
    :show-inheritance:

py\_pol.jones\_vector module
----------------------------

.. automodule:: py_pol.jones_vector
    :members:
    :undoc-members:
    :show-inheritance:

py\_pol.mueller module
----------------------

.. automodule:: py_pol.mueller
    :members:
    :undoc-members:
    :show-inheritance:

py\_pol.stokes module
---------------------

.. automodule:: py_pol.stokes
    :members:
    :undoc-members:
    :show-inheritance:

py\_pol.utils module
--------------------

.. automodule:: py_pol.utils
    :members:
    :undoc-members:
    :show-inheritance:


Module contents
---------------

.. automodule:: py_pol
    :members:
    :undoc-members:
    :show-inheritance:
