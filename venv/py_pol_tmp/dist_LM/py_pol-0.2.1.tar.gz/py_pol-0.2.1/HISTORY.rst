=======
History
=======

0.1.1 (2018-12-22)
------------------

* First release on PyPI in pre-alpha state.


0.1.3 (2019-01-22)
------------------

alpha state

* Jones_vector, Jones_matrix, Stokes works.
* Mueller is in progress.
* Functions = 9/10
* Documentation = 8/10
* Tutorial = 7/10.
* Examples = 6/10.
* Drawing = 0/10.


0.1.4 (2019-02-03)
------------------

alpha state

* Jones_vector, Jones_matrix, Stokes works.
* Mueller is in progress.
* Functions = 9/10
* Documentation = 8/10
* Tutorial = 8/10.
* Examples = 8/10.
* Tests = 8/10
* Drawing = 10/10. Finished. Polarization ellipse for Jones and Stokes (partially random). Stokes on Poincaré sphere.


0.1.5 (2019-02-25)
------------------

alpha state

* Jones_vector, Jones_matrix, Stokes works.
* Jones_vector: simplify function to represent better Jones vectors.
* tests drawing: Made tests for drawing

* Mueller is in progress.
* Functions = 9/10
* Documentation = 8/10
* Tutorial = 8/10.
* Examples = 8/10.
* Tests = 8/10
* Drawing = 10/10. Finished. Polarization ellipse for Jones and Stokes (partially random). Stokes on Poincaré sphere.


0.2.0 (2019-05-25)
------------------

beta state

* Upgrade to Python 3
* Stable version including tests


0.2.1 (2019-09-04)
------------------

beta state

* Bug fixes.
* Solve incidents.
* Start to homogenize structures for both Jones and Stokes.


0.2.2 (2019-09-04)
------------------

beta state

* Bug fixes.
