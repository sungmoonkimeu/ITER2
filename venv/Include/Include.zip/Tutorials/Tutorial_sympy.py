import numpy as np
import sympy
